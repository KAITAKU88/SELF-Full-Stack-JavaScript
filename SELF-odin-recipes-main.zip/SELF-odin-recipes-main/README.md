# odin-recipes
Đây là dự án thực hành sau chuối bài HTML Foundation.
Trong dự án này, tôi sẽ xây dựng một trang web công thức nấu ăn cơ bản.
Trang web sẽ bao gồm một trang chỉ mục chính có liên kết đến một số công thức nấu ăn. Trang web sẽ không đẹp lắm khi hoàn thành nhưng điều quan trọng cần nhớ là dự án này chỉ để xây dựng các kỹ năng HTML; tôi sẽ xem lại dự án này trong tương lai để định dạng nó bằng CSS.